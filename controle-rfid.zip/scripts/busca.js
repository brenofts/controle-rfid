// contador incrementado a cada resultado de busca encontrado
var resultadoBusca = 0
var conteudoBusca = []

// funcao executada ao final da busca informando o número de resultados encontrados
function resultadoZero(x) {
    db.ref('buscas').push().set(conteudoBusca)
    if (x == 0) {
        alert("nenhum resultado")
    } else {
        if (x == 1) {
            alert("Foi encontrado 1 resultado")
        } else {
            alert("Foram encontrados " + x + " resultados")
        }
        resultadoBusca = 0
    }
}

// BUSCA POR DATA

function buscarData(dia) {
    database
        .ref("historico")
        .once("value")
        .then((snapshot) => {
            var data = Object.values(snapshot.val())
            function gerarTabela(valores) {
                for (var i = 0; i < valores.length; i++) {
                    // a data deve ser ajustada considerando a diferença de 3h do fuso horário de brasília
                    // Daí a necessidade de adicionar 3 horas em milissegundos (10800000) à data selecionada
                    // verificar condições em horário de verão
                    var ajusteHorario = 10800000
                    var data = new Date(dia + ajusteHorario).toLocaleDateString()
                    var dataReg = new Date(valores[i].data).toLocaleDateString()
                    if (data == dataReg) {
                        console.log(valores[i])
                        resultadoBusca++
                    }
                    console.log(resultadoBusca)
                }
                return resultadoZero(resultadoBusca)
            }
            gerarTabela(data)
        })
}

// BUSCA POR MATRÍCULA

function buscarMatr(matricula) {
    db
        .ref("historico")
        .once("value")
        .then((snapshot) => {
            var data = Object.values(snapshot.val())
            function gerarTabela(valores) {
                for (var i = 0; i < valores.length; i++) {
                    var matrReg = valores[i].matricula
                    if (matricula == matrReg) {
                        console.log(valores[i])
                        resultadoBusca++
                        conteudoBusca[i] = valores[i]
                    }
                    console.log(resultadoBusca)
                }
                return resultadoZero(resultadoBusca)
            }
            gerarTabela(data)
        })
}



// BUSCA POR TP

function buscarTP(tp) {
    database
        .ref("historico")
        .once("value")
        .then((snapshot) => {
            var data = Object.values(snapshot.val())
            function gerarTabela(valores) {
                for (var i = 0; i < valores.length; i++) {
                    var tpReg = valores[i].tp
                    if (tp == tpReg) {
                        console.log(valores[i])
                        resultadoBusca++
                    }
                    console.log(resultadoBusca)
                }
                return resultadoZero(resultadoBusca)
            }
            gerarTabela(data)
        })
}

// BUSCA POR POSTO

function buscarPosto(posto) {
    database
        .ref("historico")
        .once("value")
        .then((snapshot) => {
            var data = Object.values(snapshot.val())
            function gerarTabela(valores) {
                for (var i = 0; i < valores.length; i++) {
                    var postoReg = valores[i].posto
                    if (posto == postoReg) {
                        console.log(valores[i])
                        resultadoBusca++
                    }
                    console.log(resultadoBusca)
                }
                return resultadoZero(resultadoBusca)
            }
            gerarTabela(data)
        })
}


// IMPRIMIR
// criar um <div id="imprimir"> com as informaçoes da variavel conteudoBusca
// em formato de tabela simples
// passar a id dessa div como parametro ao chamar a função imprimir()

function imprimir(tabela) {
    var mywindow = window.open('', 'PRINT', '');
  
      mywindow.document.write('<html><head><link rel="stylesheet" type="text/css" href="style.css"><title>' + document.title  + '</title>');
      mywindow.document.write('</head><body >');
      mywindow.document.write('<h1>' + document.title  + '</h1>');
      mywindow.document.write(document.getElementById(tabela).innerHTML);
      mywindow.document.write('</body></html>');
  
      return true;
  }


btnBuscaMatr.addEventListener('click', () => {
    show(buscaMatr)
})

formBuscaMatr.addEventListener('submit', (e) => {
    e.preventDefault()
    if (inputMatrBuscar.value.length >= 4 && inputMatrBuscar.value.length < 6) {
        buscarMatr(inputMatrBuscar.value)
    } else {
        alert('Preencha corretamente')
    }
})